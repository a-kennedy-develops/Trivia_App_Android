package com.example.alexk.group03_hw03;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class iTunesAppAdapter extends RecyclerView.Adapter<iTunesAppAdapter.ViewHolder> {

    ArrayList<iTunesApp> mData;

    Context mContext;
    CustomItemClickListener mListener;

    public iTunesAppAdapter(Context mContext, ArrayList<iTunesApp> mData, CustomItemClickListener mListener) {
        this.mData = mData;
        this.mContext = mContext;
        this.mListener = mListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        final View mView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.itunes_app_item, parent, false);

        final ViewHolder mViewHolder = new ViewHolder(mView);

       final ImageButton imageButton = mView.findViewById(R.id.imageButton_star);

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onItemClick(mView, mViewHolder.getAdapterPosition());
            }
        });

        return mViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        iTunesApp current_iTunesApp = mData.get(holder.getAdapterPosition());
        holder.textView_title.setText(current_iTunesApp.getAppTitle());
        holder.textView_number.setText(current_iTunesApp.getPriceNumber());
        holder.textView_currency.setText(current_iTunesApp.getPriceCurrency());
        holder.imageButton_starWhite.setImageResource(R.drawable.white_star);
        if(holder.imageButton_starWhite.isSelected()) {
            holder.imageButton_starWhite.setImageResource(R.drawable.black_star);
            Toast.makeText(mContext,"Clicked: "+position,Toast.LENGTH_LONG).show();
        }else {
            holder.imageButton_starWhite.setSelected(false);
            holder.imageButton_starWhite.setImageResource(R.drawable.white_star);
        }

        Picasso.get().load(current_iTunesApp.getUrlToImage()).into(holder.imageView_icon);
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textView_title, textView_currency, textView_number;
        ImageView imageView_icon;
        ImageButton imageButton_starWhite;

        public ViewHolder(View itemView) {
            super(itemView);

            textView_title = itemView.findViewById(R.id.textView_item_appTitle);
            textView_currency = itemView.findViewById(R.id.textView_priceCurrencyType);
            textView_number = itemView.findViewById(R.id.textView_item_pricePrice);
            imageView_icon = itemView.findViewById(R.id.imageView_item_Icon);
            imageButton_starWhite = itemView.findViewById(R.id.imageButton_star);
        }

    }

    public interface CustomItemClickListener {
        public void onItemClick(View v, int position);
    }

}
