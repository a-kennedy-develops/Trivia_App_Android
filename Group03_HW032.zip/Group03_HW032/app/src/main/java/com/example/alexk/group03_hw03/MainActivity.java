package com.example.alexk.group03_hw03;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements TopPaidAppsFragment.OnFragmentInteractionListener {

    ArrayList<iTunesApp> iTunesAppArrayList = new ArrayList<iTunesApp>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportFragmentManager().beginTransaction()
                .add(R.id.container, new TopPaidAppsFragment(), "TopList")
                .commit();

    }

    @Override
    public void TransferTopAppsList(ArrayList<iTunesApp> listOfApps) {
        iTunesAppArrayList = listOfApps;
        Log.d("demo", listOfApps.toString());

        TopPaidAppsFragment topPaidAppsFragment = (TopPaidAppsFragment) getSupportFragmentManager().findFragmentByTag("TopList");
        topPaidAppsFragment.updateList(iTunesAppArrayList);
        topPaidAppsFragment.FinishLoading();
    }
}
