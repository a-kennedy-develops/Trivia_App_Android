package com.example.alexk.group03_hw03;

import java.io.Serializable;

public class iTunesApp implements Serializable{
    String appTitle, urlToImage, priceCurrency, priceNumber;

    public iTunesApp() {
    }

    public String getAppTitle() {
        return appTitle;
    }

    public void setAppTitle(String appTitle) {
        this.appTitle = appTitle;
    }

    public String getUrlToImage() {
        return urlToImage;
    }

    public void setUrlToImage(String urlToImage) {
        this.urlToImage = urlToImage;
    }

    public String getPriceCurrency() {
        return priceCurrency;
    }

    public void setPriceCurrency(String priceCurrency) {
        this.priceCurrency = priceCurrency;
    }

    public String getPriceNumber() {
        return priceNumber;
    }

    public void setPriceNumber(String priceNumber) {
        this.priceNumber = priceNumber;
    }

    @Override
    public String toString() {
        return "iTunesApp{" +
                "appTitle='" + appTitle + '\'' +
                ", urlToImage='" + urlToImage + '\'' +
                ", priceCurrency='" + priceCurrency + '\'' +
                ", priceNumber='" + priceNumber + '\'' +
                '}';
    }
}
