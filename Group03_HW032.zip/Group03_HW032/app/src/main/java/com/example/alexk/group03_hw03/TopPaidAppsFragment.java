package com.example.alexk.group03_hw03;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class TopPaidAppsFragment extends Fragment implements iTunesAppAdapter.CustomItemClickListener {

    private OnFragmentInteractionListener mListener;
    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<iTunesApp> iTunesAppArrayList = new ArrayList<>();
    private ProgressBar progressBar;
    private TextView loadingText;
    private View view;


    public TopPaidAppsFragment() {
        // Required empty public constructor
    }

    private void SwitchList (ArrayList<iTunesApp> listOfApps) {
        iTunesAppArrayList = listOfApps;
    }

    public void FinishLoading() {
        Log.d("demo", "Inside Finish Loading");
        loadingText.setVisibility(View.INVISIBLE);
        progressBar.setVisibility(View.INVISIBLE);
    }

    public void updateList (ArrayList<iTunesApp> apps) {
        iTunesAppArrayList.clear();
        iTunesAppArrayList.addAll(apps);
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_top_paid_apps, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        loadingText = getActivity().findViewById(R.id.textView_loadingTopApps);
        progressBar = getActivity().findViewById(R.id.progressBar2);

        recyclerView = (RecyclerView) Objects.requireNonNull(getActivity()).findViewById(R.id.my_recycler_view);
        recyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        mAdapter = new iTunesAppAdapter(getActivity(), iTunesAppArrayList, new iTunesAppAdapter.CustomItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Log.d("demo", "TopPaid Index - " + position);
                ImageButton imageButton = view.findViewById(R.id.imageButton_star);

                if (!imageButton.isSelected()) {
                    imageButton.setSelected(true);
                    imageButton.setImageResource(R.drawable.black_star);
                } else if (imageButton.isSelected()) {
                    imageButton.setSelected(false);
                    imageButton.setImageResource(R.drawable.white_star);
                }
                TextView textView = view.findViewById(R.id.textView_item_appTitle);
                Log.d("demo", "Title = " + textView.getText().toString());
                Log.d("demo", "--------------------------------");
            }

        });
        recyclerView.setAdapter(mAdapter);

        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url("https://itunes.apple.com/us/rss/toppaidapplications/limit=25/json")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                final ArrayList<iTunesApp> temp_iTunesAppArrayList = new ArrayList<iTunesApp>();
                try {
                    String json = response.body().string();
                    JSONObject root = new JSONObject(json);

                    Log.d("demo", "Full json file -" + root);
                    JSONObject feedObject = root.getJSONObject("feed");
                    JSONArray entries = feedObject.getJSONArray("entry");
                    for (int i = 0; i < entries.length(); i++) {
                        JSONObject entriesJSONObject = entries.getJSONObject(i);
                        iTunesApp newITunesApp = new iTunesApp();

                        JSONObject nameObject = entriesJSONObject.getJSONObject("im:name");
                        newITunesApp.setAppTitle(nameObject.getString("label"));

                        JSONArray imageArray = entriesJSONObject.getJSONArray("im:image");
                        JSONObject index0Image = (JSONObject) imageArray.get(0);
                        newITunesApp.setUrlToImage(index0Image.getString("label"));

                        JSONObject priceObject = entriesJSONObject.getJSONObject("im:price");
                        JSONObject priceAttributesObject = priceObject.getJSONObject("attributes");
                        newITunesApp.setPriceNumber(priceAttributesObject.getString("amount"));
                        newITunesApp.setPriceCurrency(priceAttributesObject.getString("currency"));

                        temp_iTunesAppArrayList.add(newITunesApp);
                    }

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mListener.TransferTopAppsList(temp_iTunesAppArrayList);
                        }
                    });


                } catch (Exception e) {
                    Log.d("demo", "Thrown exception -" + e);
                }
            }
        });

//            mListener.TransferTopAppsList(iTunesAppArrayList);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    //Adapter
    @Override
    public void onItemClick(View v, int position) {

    }


    //Frag
    public interface OnFragmentInteractionListener {
        void TransferTopAppsList(ArrayList<iTunesApp> listOfApps);
    }
}
